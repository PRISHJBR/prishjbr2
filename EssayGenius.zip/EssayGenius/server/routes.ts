import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { generateEssaySchema } from "@shared/schema";
import { generateEssay } from "./services/openai";
import { ZodError } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Generate essay endpoint
  app.post("/api/essays/generate", async (req, res) => {
    try {
      // Validate request body
      const { topic, sources } = generateEssaySchema.parse(req.body);
      
      // Generate essay using OpenAI
      const result = await generateEssay(topic, sources);
      
      // Store the essay (optional - could be removed if not needed)
      const essay = await storage.createEssay({
        topic,
        sources,
        content: result.content,
        wordCount: result.wordCount,
        paragraphs: result.paragraphs,
        readingTime: result.readingTime,
        sourcesCount: result.sourcesCount,
      });
      
      res.json({
        success: true,
        data: {
          id: essay.id,
          title: result.title,
          content: result.content,
          wordCount: result.wordCount,
          paragraphs: result.paragraphs,
          readingTime: result.readingTime,
          sourcesCount: result.sourcesCount,
        }
      });
    } catch (error) {
      console.error("Essay generation error:", error);
      
      if (error instanceof ZodError) {
        return res.status(400).json({
          success: false,
          error: "Invalid input data",
          details: error.errors
        });
      }
      
      res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : "Failed to generate essay"
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
