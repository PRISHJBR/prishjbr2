import { users, essays, type User, type InsertUser, type Essay, type InsertEssay } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createEssay(essay: InsertEssay & { content: string; wordCount: number; paragraphs: number; readingTime: number; sourcesCount: number }): Promise<Essay>;
  getEssay(id: number): Promise<Essay | undefined>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async createEssay(essayData: InsertEssay & { content: string; wordCount: number; paragraphs: number; readingTime: number; sourcesCount: number }): Promise<Essay> {
    const [essay] = await db
      .insert(essays)
      .values(essayData)
      .returning();
    return essay;
  }

  async getEssay(id: number): Promise<Essay | undefined> {
    const [essay] = await db.select().from(essays).where(eq(essays.id, id));
    return essay || undefined;
  }
}

export const storage = new DatabaseStorage();
