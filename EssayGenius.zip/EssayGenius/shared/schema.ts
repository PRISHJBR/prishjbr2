import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const essays = pgTable("essays", {
  id: serial("id").primaryKey(),
  topic: text("topic").notNull(),
  sources: text("sources").notNull(),
  content: text("content").notNull(),
  wordCount: integer("word_count").notNull().default(0),
  paragraphs: integer("paragraphs").notNull().default(0),
  readingTime: integer("reading_time").notNull().default(0),
  sourcesCount: integer("sources_count").notNull().default(0),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertEssaySchema = createInsertSchema(essays).pick({
  topic: true,
  sources: true,
});

export const generateEssaySchema = z.object({
  topic: z.string().min(1, "Topic is required").max(500, "Topic must be under 500 characters"),
  sources: z.string().min(1, "Sources are required").max(2000, "Sources must be under 2000 characters"),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertEssay = z.infer<typeof insertEssaySchema>;
export type Essay = typeof essays.$inferSelect;
export type GenerateEssayRequest = z.infer<typeof generateEssaySchema>;
