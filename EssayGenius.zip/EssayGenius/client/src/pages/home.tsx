import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { generateEssaySchema } from "@shared/schema";
import { 
  GraduationCap, 
  Lightbulb, 
  Book, 
  Wand2, 
  Copy, 
  FileText, 
  CheckCircle, 
  Info, 
  TriangleAlert,
  Settings,
  HelpCircle,
  Check,
  Loader2
} from "lucide-react";

type FormData = {
  topic: string;
  sources: string;
};

type EssayResponse = {
  success: boolean;
  data?: {
    id: number;
    title: string;
    content: string;
    wordCount: number;
    paragraphs: number;
    readingTime: number;
    sourcesCount: number;
  };
  error?: string;
};

export default function Home() {
  const [generatedEssay, setGeneratedEssay] = useState<EssayResponse["data"] | null>(null);
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  const form = useForm<FormData>({
    resolver: zodResolver(generateEssaySchema),
    defaultValues: {
      topic: "",
      sources: "",
    },
  });

  const generateMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const response = await apiRequest("POST", "/api/essays/generate", data);
      return response.json() as Promise<EssayResponse>;
    },
    onSuccess: (data) => {
      if (data.success && data.data) {
        setGeneratedEssay(data.data);
        toast({
          title: "Essay Generated Successfully",
          description: `Generated a ${data.data.wordCount}-word essay with ${data.data.paragraphs} paragraphs.`,
        });
      } else {
        toast({
          title: "Generation Failed",
          description: data.error || "Failed to generate essay",
          variant: "destructive",
        });
      }
    },
    onError: (error) => {
      toast({
        title: "Generation Failed",
        description: error.message || "Failed to generate essay",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FormData) => {
    generateMutation.mutate(data);
  };

  const copyToClipboard = async () => {
    if (!generatedEssay) return;
    
    try {
      await navigator.clipboard.writeText(generatedEssay.content);
      setCopied(true);
      toast({
        title: "Copied to Clipboard",
        description: "Essay content has been copied to your clipboard.",
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      toast({
        title: "Copy Failed",
        description: "Failed to copy essay to clipboard.",
        variant: "destructive",
      });
    }
  };

  const topicValue = form.watch("topic");
  const sourcesValue = form.watch("sources");

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <GraduationCap className="h-8 w-8 text-primary" />
              <div className="ml-3">
                <h1 className="text-xl font-semibold text-gray-900">Essay Generator</h1>
                <p className="text-sm text-gray-500">AI-Powered Academic Writing</p>
              </div>
            </div>
            
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Input Panel */}
          <div className="space-y-6">
            {/* Instructions Card */}
            <Card className="bg-blue-50 border-blue-200">
              <CardContent className="p-6">
                <div className="flex items-center mb-3">
                  <Info className="h-5 w-5 text-blue-600 mr-2" />
                  <h3 className="text-lg font-medium text-blue-900">How to Use</h3>
                </div>
                <ol className="list-decimal list-inside space-y-1 text-sm text-blue-800">
                  <li>Enter your essay topic in the field below</li>
                  <li>Add your sources and reference materials</li>
                  <li>Click "Generate Essay" to create your content</li>
                  <li>Review, edit, and copy your generated essay</li>
                </ol>
              </CardContent>
            </Card>

            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {/* Topic Input */}
              <Card>
                <CardContent className="p-6">
                  <Label htmlFor="topic" className="flex items-center text-sm font-medium text-gray-700 mb-2">
                    <Lightbulb className="h-4 w-4 text-yellow-500 mr-2" />
                    Essay Topic
                  </Label>
                  <Textarea
                    id="topic"
                    rows={3}
                    {...form.register("topic")}
                    placeholder="Enter your essay topic here... (e.g., 'The impact of artificial intelligence on modern education')"
                    className="resize-none"
                  />
                  <div className="mt-2 flex justify-between items-center">
                    <span className="text-xs text-gray-500">Be specific and clear about your topic</span>
                    <span className="text-xs text-gray-400">{topicValue?.length || 0}/500</span>
                  </div>
                  {form.formState.errors.topic && (
                    <p className="mt-1 text-sm text-red-600">{form.formState.errors.topic.message}</p>
                  )}
                </CardContent>
              </Card>

              {/* Sources Input */}
              <Card>
                <CardContent className="p-6">
                  <Label htmlFor="sources" className="flex items-center text-sm font-medium text-gray-700 mb-2">
                    <Book className="h-4 w-4 text-green-500 mr-2" />
                    Sources & References
                  </Label>
                  <Textarea
                    id="sources"
                    rows={8}
                    {...form.register("sources")}
                    placeholder="Paste your sources here... Include URLs, book titles, articles, or any reference materials you want to include in your essay."
                    className="resize-none"
                  />
                  <div className="mt-2 flex justify-between items-center">
                    <span className="text-xs text-gray-500">Include URLs, citations, or text from your sources</span>
                    <span className="text-xs text-gray-400">{sourcesValue?.length || 0}/2000</span>
                  </div>
                  {form.formState.errors.sources && (
                    <p className="mt-1 text-sm text-red-600">{form.formState.errors.sources.message}</p>
                  )}
                </CardContent>
              </Card>

              {/* Generate Button */}
              <Card>
                <CardContent className="p-6">
                  <Button 
                    type="submit"
                    className="w-full bg-primary hover:bg-blue-700 text-white font-medium py-3 px-6"
                    disabled={generateMutation.isPending}
                  >
                    {generateMutation.isPending ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <Wand2 className="h-4 w-4 mr-2" />
                        Generate Essay
                      </>
                    )}
                  </Button>
                  
                  {generateMutation.isPending && (
                    <div className="mt-4 text-center">
                      <div className="inline-flex items-center">
                        <Loader2 className="h-5 w-5 animate-spin text-primary mr-2" />
                        <span className="text-sm text-gray-600">Generating your essay...</span>
                      </div>
                      <div className="mt-2 text-xs text-gray-500">This may take 30-60 seconds</div>
                    </div>
                  )}

                  {generateMutation.error && (
                    <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
                      <div className="flex items-center">
                        <TriangleAlert className="h-4 w-4 text-red-600 mr-2" />
                        <span className="text-sm text-red-800">
                          {generateMutation.error.message || "Error generating essay. Please try again."}
                        </span>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </form>
          </div>

          {/* Output Panel */}
          <div className="space-y-6">
            {/* Essay Output */}
            <Card className="min-h-[600px]">
              <div className="p-6 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-medium text-gray-900 flex items-center">
                    <FileText className="h-5 w-5 text-blue-600 mr-2" />
                    Generated Essay
                  </h3>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-gray-500">
                      {generatedEssay?.wordCount || 0} words
                    </span>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={copyToClipboard}
                      disabled={!generatedEssay}
                      className="flex items-center"
                    >
                      {copied ? (
                        <>
                          <Check className="h-3 w-3 mr-1" />
                          Copied!
                        </>
                      ) : (
                        <>
                          <Copy className="h-3 w-3 mr-1" />
                          Copy
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </div>
              
              <CardContent className="p-6">
                {!generatedEssay ? (
                  <div className="text-center py-16">
                    <div className="max-w-md mx-auto">
                      <FileText className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                      <h4 className="text-lg font-medium text-gray-900 mb-2">Ready to Generate</h4>
                      <p className="text-sm text-gray-500 mb-6">
                        Enter your topic and sources, then click "Generate Essay" to create your academic content.
                      </p>
                      <div className="grid grid-cols-2 gap-4 text-xs text-gray-400">
                        <div className="flex items-center">
                          <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                          AI-Powered
                        </div>
                        <div className="flex items-center">
                          <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                          Well-Structured
                        </div>
                        <div className="flex items-center">
                          <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                          Academic Style
                        </div>
                        <div className="flex items-center">
                          <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                          Source-Based
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="prose prose-slate max-w-none">
                    <h2 className="text-xl font-semibold mb-4">{generatedEssay.title}</h2>
                    <div className="space-y-4 text-gray-800 leading-relaxed whitespace-pre-wrap">
                      {generatedEssay.content}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Statistics Card */}
            <Card>
              <CardContent className="p-6">
                <h4 className="text-sm font-medium text-gray-700 mb-4">Essay Statistics</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary">{generatedEssay?.wordCount || 0}</div>
                    <div className="text-xs text-gray-500">Words</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">{generatedEssay?.paragraphs || 0}</div>
                    <div className="text-xs text-gray-500">Paragraphs</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-orange-600">{generatedEssay?.readingTime || 0}</div>
                    <div className="text-xs text-gray-500">Min Read</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600">{generatedEssay?.sourcesCount || 0}</div>
                    <div className="text-xs text-gray-500">Sources</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <h5 className="font-medium text-gray-900 mb-3">Essay Generator</h5>
              <p className="text-sm text-gray-600">
                AI-powered tool for creating well-structured academic essays based on your topics and sources.
              </p>
            </div>
            <div>
              <h5 className="font-medium text-gray-900 mb-3">Features</h5>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• AI-powered generation</li>
                <li>• Source integration</li>
                <li>• Academic formatting</li>
                <li>• Word count tracking</li>
              </ul>
            </div>
            <div>
              <h5 className="font-medium text-gray-900 mb-3">Support</h5>
              <ul className="text-sm text-gray-600 space-y-1">
                <li><a href="#" className="hover:text-primary">Help Center</a></li>
                <li><a href="#" className="hover:text-primary">Contact Us</a></li>
                <li><a href="#" className="hover:text-primary">Terms of Service</a></li>
                <li><a href="#" className="hover:text-primary">Privacy Policy</a></li>
              </ul>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-gray-200 text-center text-sm text-gray-500">
            <p>&copy; 2024 Essay Generator. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
