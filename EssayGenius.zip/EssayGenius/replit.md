# Essay Generator Application

## Overview

This is a full-stack web application that generates academic essays based on user-provided topics and sources. The application uses React for the frontend, Express for the backend, and integrates with OpenAI's GPT-4o model for essay generation. It features a modern UI built with shadcn/ui components and Tailwind CSS.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Components**: shadcn/ui component library with Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Form Handling**: React Hook Form with Zod validation
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon serverless PostgreSQL
- **AI Integration**: OpenAI API (GPT-4o model)
- **Session Management**: Connect-pg-simple for PostgreSQL session storage
- **Validation**: Zod for request/response validation

## Key Components

### Database Schema
- **Users Table**: Basic user authentication with username/password
- **Essays Table**: Stores generated essays with metadata (word count, paragraphs, reading time, sources count)
- **Schema Location**: `shared/schema.ts` using Drizzle ORM

### API Endpoints
- **POST /api/essays/generate**: Main endpoint for essay generation
  - Accepts topic and sources
  - Validates input using Zod schemas
  - Integrates with OpenAI API
  - Returns structured essay data with metadata

### Frontend Pages
- **Home Page**: Main interface for essay generation with form inputs and results display
- **404 Page**: Not found error page
- **Components**: Comprehensive UI component library from shadcn/ui

### Storage Layer
- **Interface**: `IStorage` abstraction for database operations
- **Implementation**: `DatabaseStorage` using PostgreSQL with Drizzle ORM
- **Database**: PostgreSQL database with Neon serverless connection
- **ORM**: Drizzle ORM for type-safe database operations

## Data Flow

1. User submits essay topic and sources through the frontend form
2. Frontend validates input using Zod schemas
3. API request sent to `/api/essays/generate` endpoint
4. Backend validates request and calls OpenAI API
5. OpenAI generates structured essay content
6. Essay data stored in database with metadata
7. Response returned to frontend with essay content and statistics
8. Frontend displays generated essay with copy functionality

## External Dependencies

### AI Services
- **OpenAI API**: GPT-4o model for essay generation
- **Configuration**: API key via environment variables
- **Features**: Structured JSON responses, academic writing tone

### Database
- **Neon PostgreSQL**: Serverless PostgreSQL database
- **Connection**: Via `@neondatabase/serverless` driver
- **ORM**: Drizzle ORM for type-safe database operations

### UI Framework
- **Radix UI**: Unstyled, accessible UI primitives
- **shadcn/ui**: Pre-built component library
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Icon library

## Deployment Strategy

### Development
- **Frontend**: Vite dev server with HMR
- **Backend**: tsx for TypeScript execution
- **Database**: Drizzle Kit for schema management
- **Environment**: Development mode with error overlays

### Production Build
- **Frontend**: Vite build to `dist/public`
- **Backend**: esbuild bundling to `dist/index.js`
- **Database**: Drizzle migrations in `./migrations`
- **Deployment**: Node.js production server

### Configuration
- **TypeScript**: Strict mode with ES modules
- **Path Aliases**: Configured for clean imports
- **Environment Variables**: DATABASE_URL, OPENAI_API_KEY
- **Session Storage**: PostgreSQL-based sessions for scalability

### Key Features
- **Responsive Design**: Mobile-first approach with Tailwind CSS
- **Accessibility**: Built on Radix UI primitives
- **Type Safety**: Full TypeScript coverage
- **Error Handling**: Comprehensive error boundaries and validation
- **Performance**: Optimized builds and code splitting